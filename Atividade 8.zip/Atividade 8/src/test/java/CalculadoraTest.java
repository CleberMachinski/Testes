import org.junit.Test;

import br.edu.ifpr.entidades.Calculadora;
import br.edu.ifpr.exceptions.DivisaoPorZeroException;
import junit.framework.Assert;

public class CalculadoraTest {
	
	@Test
	public void deveSomarDoisNumeros() {
		//cenario
		int num1 = 10;
		int num2 = 5;
		int resultado;
		
		Calculadora calc = new Calculadora();
		
		//acao
		resultado = calc.somar(num1, num2);
		
		//verificacao
		Assert.assertEquals(15, resultado);
	}
	
	@Test
	public void deveSubtrairDoisNumero() {
		//cenario
		int num1 = 10;
		int num2 = 5;
		int resultado;
		
		Calculadora calc = new Calculadora();
		
		//acao
		resultado = calc.subtrair(num1, num2);
		
		//verificacao
		Assert.assertEquals(5, resultado);
	}
	
	@Test(expected = DivisaoPorZeroException.class)
	public void deveLancarExcecaoDivisaoPorZero() throws DivisaoPorZeroException {
		//cenario
		int num1 = 10;
		int num2 = 0;
		
		Calculadora calc = new Calculadora();
		
		//acao
		calc.dividir(num1, num2);
	}

}
