package br.edu.ifpr.servicos;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ErrorCollector;
import org.junit.rules.ExpectedException;

import br.edu.ifpr.entidades.Filme;
import br.edu.ifpr.entidades.Locacao;
import br.edu.ifpr.entidades.Usuario;
import br.edu.ifpr.exceptions.FilmeSemEstoqueException;
import br.edu.ifpr.exceptions.LocacaoServiceException;
import br.edu.ifpr.utils.DataUtils;

public class LocacaoServiceTest {
	
	
	@Rule
	public ErrorCollector error = new ErrorCollector();
	
	@Rule
	public ExpectedException expected = ExpectedException.none();
	
	private LocacaoService service;
	
	@Before
	public void setup() {
		//System.out.println("@Before");
		service = new LocacaoService();
	}
	
	@After
	public void tearDown() {
		//System.out.println("@After");
	}
	
	
	@Test
	public void devePermitirAlugarFilme1() throws Exception {
		
		//cenario
		Usuario usuario = new Usuario("Jefferson");
		
		List<Filme> filmes = Arrays.asList(
				new Filme("Poderoso Chef�o", 5, 4.0), 
				new Filme("A vida � bela", 2, 4.0)
		);
		
		//acao
		Locacao locacao = service.alugarFilme(usuario, filmes);
		
		//verificacao
		assertTrue(DataUtils.isMesmaData(locacao.getDataLocacao(), new Date()));
		assertTrue(DataUtils.isMesmaData(locacao.getDataLocacao(),DataUtils.obterDataComDiferencaDias(0)));
		
		assertThat(locacao.getValor(), is(not(6.0)));
		assertThat(locacao.getValor(), is(equalTo(8.0)));
	}
	
	@Test
	public void devePermitirAlugarFilme2() throws Exception {
		
		//cenario
		Usuario usuario = new Usuario("Jefferson");
		
		List<Filme> filmes = Arrays.asList(
				new Filme("Poderoso Chef�o", 5, 5.0), 
				new Filme("A vida � bela", 2, 4.0)
		);
		
		Locacao locacao;
		
		//acao
		locacao = service.alugarFilme(usuario, filmes);
		
		//verificacao
		error.checkThat(locacao.getValor(), is(equalTo(9.0)));				
	}
	
	@Test
	public void devePermitirAlugarFilme3() throws Exception {
		
		//cenario
		Usuario usuario = new Usuario("Jefferson");
		
		List<Filme> filmes = Arrays.asList(
				new Filme("Tenet", 8, 3.0),
				new Filme("Godzilla", 2, 1.0),
				new Filme("O Chal�", 5, 1.0)		
		);
		
		//acao
		Locacao locacao = service.alugarFilme(usuario, filmes);
		
		//verificacao
		assertTrue(DataUtils.isMesmaData(locacao.getDataLocacao(), new Date()));
		assertTrue(DataUtils.isMesmaData(locacao.getDataLocacao(),DataUtils.obterDataComDiferencaDias(0)));
		
		assertThat(locacao.getValor(), is(not(6.0)));
		assertThat(locacao.getValor(), is(equalTo(3.75)));
	}
	
	@Test
	public void devePermitirAlugarFilme4() throws Exception {
		
		//cenario
		Usuario usuario = new Usuario("Jefferson");
		
		List<Filme> filmes = Arrays.asList(
				new Filme("Tenet", 8, 3.0),
				new Filme("Godzilla", 2, 1.0),
				new Filme("O Chal�", 5, 1.0), 
				new Filme("Tempestade", 10, 8.0)
		);
		
		//acao
		Locacao locacao = service.alugarFilme(usuario, filmes);
		
		//verificacao
		assertTrue(DataUtils.isMesmaData(locacao.getDataLocacao(), new Date()));
		assertTrue(DataUtils.isMesmaData(locacao.getDataLocacao(),DataUtils.obterDataComDiferencaDias(0)));
		
		assertThat(locacao.getValor(), is(not(6.0)));
		assertThat(locacao.getValor(), is(equalTo(6.5)));
	}
	
	@Test
	public void devePermitirAlugarFilme5() throws Exception {
		
		//cenario
		Usuario usuario = new Usuario("Jefferson");
		
		List<Filme> filmes = Arrays.asList(
				new Filme("Tenet", 8, 3.0),
				new Filme("Godzilla", 2, 1.0),
				new Filme("O Chal�", 5, 1.0), 
				new Filme("Tempestade", 10, 8.0),
				new Filme("Jogador", 2, 3.0)
		);
		
		//acao
		Locacao locacao = service.alugarFilme(usuario, filmes);
		
		//verificacao
		assertTrue(DataUtils.isMesmaData(locacao.getDataLocacao(), new Date()));
		assertTrue(DataUtils.isMesmaData(locacao.getDataLocacao(),DataUtils.obterDataComDiferencaDias(0)));
		
		assertThat(locacao.getValor(), is(not(6.0)));
		assertThat(locacao.getValor(), is(equalTo(4.0)));
	}
	
	@Test
	public void devePermitirAlugarFilme6() throws Exception {
		
		//cenario
		Usuario usuario = new Usuario("Jefferson");
		
		List<Filme> filmes = Arrays.asList(
				new Filme("Tenet", 8, 3.0),
				new Filme("Godzilla", 2, 1.0),
				new Filme("O Chal�", 5, 1.0), 
				new Filme("Tempestade", 10, 8.0),
				new Filme("Jogador", 2, 3.0),
				new Filme("After", 1, 12.0)
		);
		
		//acao
		Locacao locacao = service.alugarFilme(usuario, filmes);
		
		//verificacao
		assertTrue(DataUtils.isMesmaData(locacao.getDataLocacao(), new Date()));
		assertTrue(DataUtils.isMesmaData(locacao.getDataLocacao(),DataUtils.obterDataComDiferencaDias(0)));
		
		assertThat(locacao.getValor(), is(not(6.0)));
		assertThat(locacao.getValor(), is(equalTo(0.0)));
	}
	
	//METODO 1
	@Test(expected = FilmeSemEstoqueException.class)
	public void deveLancarExcecaoQuandoNaoTiverEstoque() throws FilmeSemEstoqueException, LocacaoServiceException {
		
		//cenario
		Usuario usuario = new Usuario("Jefferson");
		
		List<Filme> filmes = Arrays.asList(
				new Filme("Poderoso Chef�o", 0, 5.0), 
				new Filme("A vida � bela", 2, 4.0)
		);
		
		
		//acao
		service.alugarFilme(usuario, filmes); //execucao para aqui
	}
	
	//METODO 2
	@Test
	public void deveLancarExcecaoQuandoNaoTiverEstoque2() throws LocacaoServiceException {
		
		//cenario
		Usuario usuario = new Usuario("Jefferson");
		
		List<Filme> filmes = Arrays.asList(
				new Filme("Poderoso Chef�o", 0, 5.0), 
				new Filme("A vida � bela", 2, 4.0)
		);
		
		
		//acao
		try {
		
			 service.alugarFilme(usuario, filmes);
			 Assert.fail("teste deve lan�ar uma exce��o");
			 
		} catch (FilmeSemEstoqueException e) {
			
			 Assert.assertThat(e.getMessage(), is("filme sem estoque"));
		}
		 
		 //outro algoritmo...
	}
	
	//METODO 3
	@Test
	public void deveLancarExcecaoQuandoNaoTiverEstoque3() throws FilmeSemEstoqueException, LocacaoServiceException {
		
		//cenario
		Usuario usuario = new Usuario("Jefferson");
		
		List<Filme> filmes = Arrays.asList(
				new Filme("Poderoso Chef�o", 0, 5.0), 
				new Filme("A vida � bela", 2, 4.0)
		);
		
		expected.expect(FilmeSemEstoqueException.class);
		expected.expectMessage("filme sem estoque");
		
		//acao
		service.alugarFilme(usuario, filmes); 
	}
	
	
	@Test
	public void deveLancarExcecaoQuandoFilmeEstiverNulo() throws FilmeSemEstoqueException {
		//Cenario
		Usuario usuario = new Usuario("jefferson");
		
		//acao
		try {
			service.alugarFilme(usuario, null);
			Assert.fail();
		
		} catch (LocacaoServiceException e) {	
			Assert.assertThat(e.getMessage(), is("filme nulo"));
		}
	}
	
	
	
	
	
	
	
}
