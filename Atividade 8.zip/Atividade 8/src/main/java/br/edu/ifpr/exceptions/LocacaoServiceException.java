package br.edu.ifpr.exceptions;

public class LocacaoServiceException extends Exception {

	private static final long serialVersionUID = 8954623558516512822L;

	public LocacaoServiceException(String message) {
		super(message);
	}
	
}
