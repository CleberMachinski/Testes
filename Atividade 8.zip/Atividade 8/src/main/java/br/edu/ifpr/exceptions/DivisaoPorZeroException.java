package br.edu.ifpr.exceptions;

public class DivisaoPorZeroException extends Exception {

	private static final long serialVersionUID = -3325517947691061744L;

	public DivisaoPorZeroException(String message) {
		super(message);
	}
}
