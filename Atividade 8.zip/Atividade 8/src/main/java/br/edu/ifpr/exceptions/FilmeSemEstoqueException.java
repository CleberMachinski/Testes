package br.edu.ifpr.exceptions;

public class FilmeSemEstoqueException extends Exception {

	private static final long serialVersionUID = 3864394934824610211L;

	public FilmeSemEstoqueException(String message) {
		super(message);
	}
	
	
}
