package br.edu.ifpr.servicos;

import static br.edu.ifpr.utils.DataUtils.adicionarDias;

import java.util.Date;
import java.util.List;

import br.edu.ifpr.entidades.Filme;
import br.edu.ifpr.entidades.Locacao;
import br.edu.ifpr.entidades.Usuario;
import br.edu.ifpr.exceptions.FilmeSemEstoqueException;
import br.edu.ifpr.exceptions.LocacaoServiceException;



public class LocacaoService {
		
	public Locacao alugarFilme(Usuario usuario, List<Filme> filmes) throws FilmeSemEstoqueException, LocacaoServiceException {
		
		if(filmes == null) {
			throw new LocacaoServiceException("filme nulo");
		}
		
		if(usuario == null) {
			throw new LocacaoServiceException("usuario nulo");
		}
		
		for (Filme filme : filmes) {
			if (filme.getEstoque() == 0) {
				throw new FilmeSemEstoqueException("filme sem estoque");
			}
		}
		
		
		Locacao locacao = new Locacao();
		Double precoLocacao = 0.0;

		for (Filme filme : filmes) {
			locacao.getFilmes().add(filme);
		}
		
		locacao.setUsuario(usuario);
		locacao.setDataLocacao(new Date());
		
		int i = 0;
		for (Filme filme : filmes) {
			i++;
			precoLocacao += filme.getPrecoLocacao();
		}
		
		
		precoLocacao = new LocacaoService().verificacaoDesconto(i, precoLocacao);
		
		locacao.setValor(precoLocacao);
		System.out.println("Pre�o com desconto: R$" + precoLocacao);

		//Entrega no dia seguinte
		Date dataEntrega = new Date();
		dataEntrega = adicionarDias(dataEntrega, 1);
		locacao.setDataRetorno(dataEntrega);
	
		//Salvando a locacao...	
		//TODO adicionar m�todo para salvar
		return locacao;
	}

	private double verificacaoDesconto(int i, double precoLocacao) {
		if (i == 3) {			
			System.out.println("\n25% de Desconto");
			System.out.println("Pre�o sem desconto: R$" + precoLocacao);
			double porcentagem = 0.25;
			double desconto = precoLocacao * porcentagem ;
			double valorFinal = precoLocacao - desconto;
			precoLocacao = valorFinal;
		} else if (i == 4) {			
			System.out.println("\n50% de Desconto");
			System.out.println("Pre�o sem desconto: R$" + precoLocacao);
			double porcentagem = 0.50;
			double desconto = precoLocacao * porcentagem ;
			double valorFinal = precoLocacao - desconto;
			precoLocacao = valorFinal;
		} else if (i == 5) {			
			System.out.println("\n75% de Desconto");
			System.out.println("Pre�o sem desconto: R$" + precoLocacao);
			double porcentagem = 0.75;
			double desconto = precoLocacao * porcentagem ;
			double valorFinal = precoLocacao - desconto;
			precoLocacao = valorFinal;
		} else if (i == 6) {			
			System.out.println("\n100% de Desconto");
			System.out.println("Pre�o sem desconto: R$" + precoLocacao);
			double porcentagem = 1.00;
			double desconto = precoLocacao * porcentagem ;
			double valorFinal = precoLocacao - desconto;
			precoLocacao = valorFinal;
		}
		return precoLocacao;
		
	}

	public static void main(String[] args) {
		
	}
}